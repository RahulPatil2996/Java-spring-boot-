package com.csi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJpacrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpacrudApplication.class, args);
	}

}
