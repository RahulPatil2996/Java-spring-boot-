# springboot_datajpa

Spring Boot | Data JPA | MySQL | Project Lombok | 
Swagger UI/Postman API

Employee Mangement- CRUD

Data JPA- Java Persistence API
Hibernate- ORM
Additional Features-> InBuild Methods
                   -> Custom methods

Swagger UI Dependency-

<dependency>
			<groupId>org.springdoc</groupId>
			<artifactId>springdoc-openapi-ui</artifactId>
			<version>1.5.12</version>
		</dependency>
		<dependency>
			<groupId>io.springfox</groupId>
			<artifactId>springfox-swagger2</artifactId>
			<version>2.7.0</version>
		</dependency>
		<dependency>
			<groupId>io.springfox</groupId>
			<artifactId>springfox-swagger-ui</artifactId>
			<version>2.7.0</version>
		</dependency>

